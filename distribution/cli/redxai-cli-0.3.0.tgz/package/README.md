# REDXAI CLI

Download the official `redxai-cli-<version>.tgz` and `SHA256SUMS-cli` from a public RedXDexAiBridge release. Only the selected CLI package is distributed there; the CLI source repository remains private. The desktop Bridge downloads this package directly; it does not send you to the repository page. This CLI requires Node.js 20 or later.

Verify the package checksum, then install it with `npm install --global --ignore-scripts ./redxai-cli-<version>.tgz`. The release workflow does not publish to npm automatically.

```text
REDXAI bridge download
REDXAI bridge download --output ./downloads
REDXAI bridge install
REDXAI update
REDXAI update --download-only
REDXAI version
```

On Windows PowerShell with script execution restricted, use `REDXAI.cmd` for the same commands. No execution-policy changes are necessary.

Every download resolves the official stable GitHub release and verifies its published SHA-256 checksum, advertised size, and GitHub digest when available. Existing files are never overwritten. Windows installations require a valid signature or the user's explicit `--allow-unsigned` flag for an unsigned official build; invalid signatures are always refused. Linux AppImages install per-user without elevation. A Debian download must be installed with the user's package manager. macOS is refused until the official release contains a matching macOS installer.

`REDXAI update` downloads and verifies the stable CLI package, then asks the existing npm CLI to install it globally with lifecycle scripts disabled. It never requests administrator privileges. `--download-only` performs no installation.

GenDragoon receiver/CloudCLI activation remains unavailable until its backend is deployed; these commands continue to fail closed.
