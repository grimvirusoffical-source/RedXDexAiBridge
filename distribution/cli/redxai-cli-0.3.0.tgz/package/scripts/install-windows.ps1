param([string]$AppId='gdssd')
$ErrorActionPreference='Stop'
if($AppId -ne 'gdssd'){throw "Unregistered app"}
$base = if($env:REDX_INSTALL_BASE){$env:REDX_INSTALL_BASE}else{'https://github.com/grimvirusoffical-source/gendragoon-cloud-ssd/releases/latest/download'}
if(!$base.StartsWith('https://')){throw 'HTTPS required'}
$arch = switch($env:PROCESSOR_ARCHITECTURE){'AMD64'{'x64'} 'ARM64'{'arm64'} default{throw 'Unsupported CPU'}}
$dir=Join-Path $env:TEMP ([guid]::NewGuid().ToString()); New-Item -ItemType Directory $dir | Out-Null
try{
 $name="gdssd-windows-$arch.exe"; $file=Join-Path $dir $name; $sha=Join-Path $dir "$name.sha256"
 Invoke-WebRequest "$base/$name" -OutFile $file
 Invoke-WebRequest "$base/$name.sha256" -OutFile $sha
 $expected=((Get-Content $sha -Raw).Trim() -split '\s+')[0]
 if($expected -notmatch '^[a-fA-F0-9]{64}$'){throw 'Invalid checksum'}
 if((Get-FileHash $file -Algorithm SHA256).Hash -ne $expected){throw 'Hash mismatch'}
 if((Get-AuthenticodeSignature $file).Status -ne 'Valid'){throw 'Unsigned or invalid installer'}
 Start-Process -Wait -FilePath $file
}finally{Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue}
