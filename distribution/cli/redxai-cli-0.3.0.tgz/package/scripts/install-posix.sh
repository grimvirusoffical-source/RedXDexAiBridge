#!/usr/bin/env bash
set -euo pipefail
app="${1:-gdssd}"
[[ "$app" =~ ^[a-z0-9-]+$ ]] || { echo 'Invalid app ID' >&2; exit 2; }
base="${REDX_INSTALL_BASE:-https://github.com/grimvirusoffical-source/gendragoon-cloud-ssd/releases/latest/download}"
[[ "$app" == "gdssd" ]] || { echo 'Unregistered app: '$app >&2; exit 2; }
[[ "$base" == https://* ]] || { echo 'HTTPS required' >&2; exit 2; }
case "$(uname -s)" in Darwin) os=macos;; Linux) os=linux;; *) exit 2;; esac
case "$(uname -m)" in arm64|aarch64) arch=arm64;; x86_64|amd64) arch=x64;; *) exit 2;; esac
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
name="gdssd-$os-$arch"
curl -fLsS --proto '=https' --tlsv1.2 "$base/$name.tar.gz" -o "$tmp/archive.tar.gz"
curl -fLsS --proto '=https' --tlsv1.2 "$base/$name.sha256" -o "$tmp/archive.sha256"
(cd "$tmp"; shasum -a 256 -c archive.sha256)
echo 'Verified release downloaded. Native package installation requires signed release policy; see README.' >&2
exit 3
