param([Parameter(Mandatory=$true)][string]$Installer,[switch]$AllowUnsigned)
$ErrorActionPreference='Stop'
$item=Get-Item -LiteralPath $Installer
if($item.Name -notmatch '^RedXDexAiBridge-\d+\.\d+\.\d+-windows-x64-setup\.exe$'){throw 'Unexpected Bridge installer name'}
$signature=Get-AuthenticodeSignature -LiteralPath $item.FullName
if($signature.Status -ne 'Valid' -and -not $AllowUnsigned){throw 'This Windows installer is unsigned. Review the verified official download; use --allow-unsigned only if you explicitly trust this build.'}
if($signature.Status -notin @('Valid','NotSigned')){throw 'The installer signature is invalid; refusing to run it.'}
$process=Start-Process -FilePath $item.FullName -Wait -PassThru
if($process.ExitCode -ne 0){throw "Bridge setup returned $($process.ExitCode)"}
